<?php

class user{

	function insertIntoBase($dato)
	{
		$conn = conexion("root", "");
		$consulta = $conn ->prepare("insert into InAndOut(NAMES.Fname, NAMES.Lname) values(CURDATE(), NAMES.Fname, NAMES.Lname, time()");
	}

	function verificar($ID)
	{
		$conn = conexion("root", "");
		$consulta = $conn ->prepare("select * from NAMES where ID = :ID");
		$consulta -> execute(array(':ID' => $ID));
		$resultado = $consulta -> fetchAll();
		return $resultado;
	}


}




?>