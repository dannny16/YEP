<?php
require('functions.php');
session_start();
//echo "welcome ".$_SESSION['userName'];
	//if no session is open it send it back to login
      if(!isset($_SESSION['userName']))
      {
      header("location: login.php"); 
      } 
//close and destroy session after clicking logout
if(isset($_POST['logout']))
{
	session_start();
	session_destroy();
	header('location: login.php');
	exit;
}

if(isset($_POST['accessAdmin']))
{
	$userName = $_POST['userName'];
    $pass = $_POST['pass'];
    $pass = hash('sha512', $_POST['pass']);
    $resultado = checkAdmin($userName, $pass);

        if($resultado == 1)
        {
         	$_SESSION['admin2'] = $userName;
         	header('location: admin/html/basic-table.html');
         	header('location: admin/html/index.html');
            header('location: admin/html/profile.html');
            header('location: admin/html/index.html');
        }
}

//require('functions.php');

$servername = "localhost";
$username = "root";
$password = "";
date_default_timezone_set("America/Tijuana");
$date = date("m/d/Y");
$DIA = date("m/d/Y");
$time = date("h:i a");

try {
    $conn = new PDO("mysql:host=$servername;dbname=YEP", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "Connected successfully"; 
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }

 //    echo "<br>Today is " . date("m/d/Y");
 //    date_default_timezone_set("America/Tijuana");
	// echo "<br>The time is " . date("h:i:sa") ."<br>";

	// 		if(isset($_POST['InOut']))
	// 		{
	// 			{
	// 				$data = array(
	// 						$_POST['ID']);
	// 			}
	// 			foreach ($data as $dato) {
	// 				echo $dato;
	// 			}
	// 		} 


 //       if(isset($_POST["Export"]))
 //       {
		 
	// 	$sql = "SELECT * FROM `InAndOut` ORDER BY `dia` ASC";

	//     $sth = $conn->prepare($sql);
	//     $sth->bindValue(':ID', $_SESSION['ID'], PDO::PARAM_INT);
	//     $sth->execute();

	//     $filename = $_SESSION['ID'].'-'.date('d.m.Y').'.csv';

	//     $data = fopen($filename, 'w');

	//     while ($row = $sth->fetch(PDO::FETCH_ASSOC)) {
	//         fputcsv($data, $row);
	//     }

	//     fclose($data);
	// }


?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Registro</title>
	<link rel="stylesheet" href="css/login.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
	<!-- <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css"> -->	
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">


	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>

</head>
<body>

<nav class="navbar navbar-expand-lg  bg-dark" style="background-color: #ed872d;">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">

      <form method="POST" name='logout'>
      <button class="navbar-brand btn btn-outline-secondary " type="submit" name="logout">Logout</button>
  </form>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
<!--     <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
 		<li class="active"><a href="">Home</a></li>
 		<li><a href="">About</a></li>
 		<li><a href="">Contact</a></li>
      </ul> -->
      
      <!-- <ul class="nav navbar-nav navbar-right" style=" #ed872d"> -->
<!--         <li><a href="#">Sign Up <i class="fas fa-user-plus"></i></a></li> -->
        <!-- <li><a href="admin/html/index.html">Admin Login <i class="fas fa-user"></i></a></li>
 
      </ul> -->


<!--     <div class="container">
        <div class="collapse navbar-collapse navbar-right" id="exCollapsingNavbar"> -->
<form method="POST" name='accessAdmin'>
            <ul class="nav navbar-nav flex-row justify-content-between ml-auto">
                
                <li class="dropdown order-1">
                    <button type="button" id="dropdownMenu1" data-toggle="dropdown" class="btn btn-outline-secondary dropdown-toggle">Login <span class="caret"></span></button>
                    <ul class="dropdown-menu dropdown-menu-right mt-2">
                       <li class="px-3 py-2">
                           <form class="form" role="form">
                                <div class="form-group">
                                    <input id="emailInput" placeholder="User Name" class="form-control form-control-sm" type="text" name="userName" required="">
                                </div>
                                <div class="form-group">
                                    <input id="passwordInput" placeholder="Password" class="form-control form-control-sm" type="password" name="pass"required="">
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-block" name="accessAdmin">Login</button>
                                </div>
<!--                                 <div class="form-group text-center">
                                    <small><a href="#" data-toggle="modal" data-target="#modalPassword">Forgot password?</a></small>
                                </div> -->
                            </form>
                        </li>
                    </ul>
                </li>
            </ul>
<!--         </div>
    </div> -->
</form>

    </div><!-- /.navbar-collapse -->
  <!-- </div> --><!-- /.container-fluid -->
</nav>





	<div class="contenedor-form">
		<h1>Welcome YEP Students</h1>
		<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
			
			<input type="number" name="ID" class="input-control" placeholder="Enter your ID number">
			

			<input type="submit" value="In / Out" name="InOut" class="log-btn" value="Submit">

			</form>
			
			<?php
			if(isset($_POST['InOut']))
			{
				//$ID = $_POST['ID'];
				$ID = hash('sha512', $_POST['ID']);
				//$ID = substr($ID, 0, 15);
				//echo $ID;
				$resultado = checkUserExist($ID);
				$resultado2 = checkUserExistInAndOut($ID);
				$dia = currentDay($ID, $DIA);
				//echo "hooooola" .$dia;

				//to sign in
				if (!empty($ID)  && $resultado ==1 && $resultado2 == 0 || $dia != $date && !empty($ID)  && $resultado ==1) 
					{
							$Fname =Fname($ID);
							$Lname =Lname($ID);
					    	$sql = "INSERT INTO InAndOut (ID, dia, Fname, Lname, Tin, Tout) values ('$ID', '$date', '$Fname' , '$Lname', '$time' , '')";
							$conn-> exec($sql);
							//echo "New record created successfully";
							echo "<p id='connectMsg'>Welcome " .$Fname. " your time in is " . date("h:ia");
					    
					}
				
				//to sign out
				/*else*/ if(!empty($ID)  && $resultado2 == 1 && $dia == $date)
				{
					$sql = "UPDATE InAndOut SET Tout = '$time' WHERE ID = '$ID' AND dia = '$date'";
					$conn-> exec($sql);
					//echo "New record successfully updated";
					echo "<p id='connectMsg'>Your time out is " . date("h:ia");
				}					
			}

			//to handle if an ID is not entered or the ID is not in the databse
			if(isset($_POST['InOut']))
			{	
				//$InOut= $_POST['InOut'];
			if (!empty($ID) && $resultado ==1 && $resultado2 ==0) 
				{
					date_default_timezone_set("America/Tijuana");
					//echo "<p id='connectMsg'>Your time in is " . date("h:ia");
				}
			//else
			if(empty($ID) || $resultado !=1) 
				{
					 echo "<p id='connectMsg' class='alert alert-success'>You did not enter an ID or Your ID was incorrect. Please enter a correct ID number into this form field.</p>";
				}
			}

			?>



		<!-- </form> -->
		<?php if(!empty($error)): ?>
			<p class="error"><?php echo $error ?></p>
		<?php endif; ?>
		<div class="registrar">
			<a href="login.php">Staff?</a>
		</div>
	</div>

<div class="footer">
  <p>2019 &copy; HOMMIE UP YEP PROGRAM</p>
</div>

<script>
	//script to remove echos
  setTimeout(function()
  {
    document.getElementById('connectMsg').style.display = 'none';
  }, 8000);
</script>

<script>
	//script to ovid writing again when refreshing page
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>

</body>
</html>