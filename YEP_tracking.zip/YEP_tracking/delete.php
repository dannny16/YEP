<?php
ob_start();
	include'functions.php';
	
?>

<html>
<body>
<?php
if(isset($_GET['id']))
{
date_default_timezone_set("America/Tijuana");
$Day = date("m/d/Y");
$ID=$_GET['id'];
$conn = conexion("root", "");
$stmt = $conn->prepare ("DELETE FROM InAndOut WHERE id= '$ID' AND dia = '$Day'");
$stmt->execute();
if($stmt)
{
	header("location: admin/html/index.html");
	exit();
}else{
     
    header("location: admin/html/index.html");
    exit();
}
}
?>
</body>
</html>