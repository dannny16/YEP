<?php

	function conexion($username, $password)
	{
	try {
	    $conn = new PDO("mysql:host=localhost;dbname=YEP", $username, $password);
	    // set the PDO error mode to exception
	    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	    //echo "Connected successfully"; 
	    }
	catch(PDOException $e)
	    {
	    echo "Connection failed: " . $e->getMessage();
	    }
	    return $conn;
	}

   function checkUserExist($ID){
   		//if(isset($_POST[$ID]))
   		//{
   			$conn = conexion("root", "");
	        $stmt = $conn->prepare ("SELECT ID from NAMES WHERE ID =:ID");
	        $stmt->bindParam(':ID', $ID);
	    	$stmt->execute();

	    	if($stmt->rowCount() > 0){
	       	 return $resultado = 1;
	    	} else {
	        	return $resultado = 0;
	    	}
    	//}
    }

    function Fname($ID)
    {
    		$conn = conexion("root", "");
	        $stmt = $conn->prepare ("SELECT Fname from NAMES WHERE ID =:ID");
	     	$stmt->bindParam(':ID', $ID);
	    	$stmt->execute();

	    	while($row=$stmt->fetch())
	    	{
	    		$Fname=$row['Fname'];
	    	}
	       	 return $Fname;
    }

    function Lname($ID)
    {
    		$conn = conexion("root", "");
	        $stmt = $conn->prepare ("SELECT Lname from NAMES WHERE ID =:ID");
	     	$stmt->bindParam(':ID', $ID);
	    	$stmt->execute();

	    	while($row=$stmt->fetch())
	    	{
	    		$Lname=$row['Lname'];
	    	}
	       	 return $Lname;
    }

   function checkUserExistInAndOut($ID)
   {

   			$conn = conexion("root", "");
	        $stmt = $conn->prepare ("SELECT ID from InAndOut WHERE ID =:ID");
	        $stmt->bindParam(':ID', $ID);
	    	$stmt->execute();

	    	if($stmt->rowCount() > 0){
	       	 return $resultado = 1;
	    	} else {
	        	return $resultado = 0;
	    	}
    }

    //to pull day
    function currentDay($ID, $DIA)
    {
   			$conn = conexion("root", "");
	        $stmt = $conn->prepare ("SELECT dia from InAndOut WHERE ID =:ID AND dia = :DIA");
	        $stmt->bindParam(':ID', $ID);
	        $stmt->bindParam(':DIA', $DIA);
	    	$stmt->execute();

	    	while($row=$stmt->fetch())
	    	{
	    		$dia=$row['dia'];
	    		return $dia;
	    	}
	       	 //return $dia;

    }

    function fillTodayTable()
    {
    	date_default_timezone_set("America/Tijuana");
    	$Day = date("m/d/Y");
    	$conn = conexion("root", "");
	    $stmt = $conn->prepare ("SELECT ID, dia, Fname, Lname, Tin, Tout from InAndOut WHERE dia = '$Day' ORDER BY dia ASC");
	    $stmt->bindParam(':ID', $ID);
	    $stmt->bindParam(':dia', $DIA);
	    $stmt->bindParam(':Fname', $Fname);
	    $stmt->bindParam(':Fname', $Lname);
	    $stmt->bindParam(':Tin', $Tin);
	    $stmt->bindParam(':Tout', $Tout);
	    $stmt->execute();

	    	while($row=$stmt->fetch())
	    	{
				echo "<tr><td>" .$row['dia']."</td><td>". $row['Fname']. "</td><td>" .$row['Lname']. "</td><td>".$row['Tin']."</td><td>". $row['Tout']."</td><td>"."<a href='../../update.php?id=".$row['ID']."'><span  class='btn btn-success btn-xs'>UPDATE</span></a>"."</td><td>"."<a href='../../delete.php?id=".$row['ID']."'><span  class='btn btn-danger btn-xs'>DELETE</span></a>"."</td><tr>";
	    	}
	    	echo "</table>";
    }

    function fillMonthTable()
    {
    	date_default_timezone_set("America/Tijuana");
    	$Day = date("m/d/Y");
    	$conn = conexion("root", "");
	    $stmt = $conn->prepare ("SELECT ID, dia, Fname, Lname, Tin, Tout from InAndOut ORDER BY dia ASC");
	    $stmt->bindParam(':ID', $ID);
	    $stmt->bindParam(':dia', $DIA);
	    $stmt->bindParam(':Fname', $Fname);
	    $stmt->bindParam(':Fname', $Lname);
	    $stmt->bindParam(':Tin', $Tin);
	    $stmt->bindParam(':Tout', $Tout);
	    $stmt->execute();

	    	while($row=$stmt->fetch())
	    	{
	    		echo "<tr><td>" .$row['ID']."</td><td>". $row['dia']. "</td><td>" .$row['Fname']. "</td><td>".$row['Lname']."</td><td>". $row['Tin']."</td><td>".$row['Tout']."</td></tr>";
	    		echo "<p></p>";
	    	}
	    	echo "</table>";
    }


    function totalSignIn()
    {
    	$total=0;
    	date_default_timezone_set("America/Tijuana");
    	$Day = date("m/d/Y");
    	$conn = conexion("root", "");
	    $stmt = $conn->prepare ("SELECT Tin from InAndOut WHERE dia = '$Day'");
	    $stmt->bindParam(':Tin', $Tin);
	    $stmt->execute();
	    	while($row=$stmt->fetch())
	    	{
	    		$total+=1;
	    	}
	    return $total;
    }

    function didNotSignOut()
    {
    	$total=0;
    	date_default_timezone_set("America/Tijuana");
    	$Day = date("m/d/Y");
    	$conn = conexion("root", "");
	    $stmt = $conn->prepare ("SELECT Tout from InAndOut WHERE dia = '$Day' AND Tout = ''");
	    $stmt->bindParam(':Tout', $Tout);
	    $stmt->execute();
	    	while($row=$stmt->fetch())
	    	{
	    		$total+=1;
	    	}
	    return $total;
    }

   function checkAdmin($userName, $pass){
   		//if(isset($_POST[$ID]))
   		//{
   			$conn = conexion("root", "");
	        $stmt = $conn->prepare ("SELECT userName from LogIn WHERE pass =:pass AND userName =:userName");
	        $stmt->bindParam(':pass', $pass);
	        $stmt->bindParam(':userName', $userName);
	    	$stmt->execute();

	    	if($stmt->rowCount() > 0){
	       	 return $resultado = 1;
	    	} else {
	        	return $resultado = 0;
	    	}
    	//}
    }


    function viewByMonth($selection)
    {
    	date_default_timezone_set("America/Tijuana");
    	$Day = date("m/d/Y");
    	$conn = conexion("root", "");
	    $stmt = $conn->prepare ("SELECT dia, Fname, Lname, Tin, Tout from InAndOut WHERE dia LIKE '$selection%' ORDER BY dia ASC");
	    $stmt->bindParam(':dia', $DIA);
	    $stmt->bindParam(':Fname', $Fname);
	    $stmt->bindParam(':Fname', $Lname);
	    $stmt->bindParam(':Tin', $Tin);
	    $stmt->bindParam(':Tout', $Tout);
	    $stmt->execute();

	    	while($row=$stmt->fetch())
	    	{
	    		echo "<tr><td>" .$row['dia']."</td><td>". $row['Fname']. "</td><td>" .$row['Lname']. "</td><td>".$row['Tin']."</td><td>". $row['Tout']."</td><td>";
	    		echo "<p></p>";
	    	}
	    	echo "</table>";
	}


	if(isset($_POST["Export"]))
	{
	  header('Content-Type: text/csv; charset=utf-8');
      header('Content-Disposition: attachment; filename=data.csv');
      ob_end_clean();  
      $output = fopen("php://output", "w");  
      fputcsv($output, array('DAY', 'NAME', 'LAST NAME', 'TIME IN', 'TIME OUT'));  
      $conn = conexion("root", "");
      $stmt = $conn->prepare ("SELECT dia, Fname, Lname, Tin, Tout from InAndOut ORDER BY dia ASC");

	  $stmt->execute();
	  //ob_end_clean();
      while ($row = $stmt->fetch(PDO::FETCH_ASSOC))  
      {  
           fputcsv($output, $row);
      }
      fclose($output);
      exit();
	}



?>