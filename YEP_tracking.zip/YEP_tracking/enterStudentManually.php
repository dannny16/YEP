<?php
ob_start();
    include'functions.php';
    
?>

<html>
<body>
<?php
if(isset($_GET['Id']))
{
    $id = $_GET['Id'];
echo "Hola ".$id ;
}
?>
</body>
</html>               






