<?php
  ob_start();
	include'functions.php';
	
?>

<html>
    <head>
<style>
  
  .log-btn{
  width: 100%;
  height: 50px;
  border: none;
  background: #2c3e50;
  color: #fff;
  cursor: pointer;
  border-radius: 4px;
  -moz-border-radius: 4px;
  -webkit-border-radius: 4px;
  margin-bottom: 15px;
}

.input-control{
  width: 100%;
  height: 50px;
  margin-bottom: 15px;
  padding: 5px 7px 5px 15px;
  border: none;
  color: #666;
  border: 2px solid #ccc;
  border-radius: 4px;
  -moz-border-radius: 4px;
  -webkit-border-radius: 4px;
}
</style>

        <title>UPDATE</title>
        <link rel="stylesheet" href="uikit/css/uikit.min.css" />
       <!-- <script src="uikit/js/jquery.js"></script> -->
        
        <!-- Jquery JS File -->
        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        
        <!-- UI KIT JS File -->
        <script src="uikit/js/uikit.min.js"></script>
        <script src="uikit/js/uikit-icons.min.js"></script>
      
    </head>
    <body>
    
   <?php
require_once 'functions.php';
?> 


<?php
date_default_timezone_set("America/Tijuana");
$Day = date("m/d/Y");
if(isset($_GET['id']))
{
$ID=$_GET['id'];

if(isset($_POST['submit']))
{
$Tin=$_POST['Tin'];
$Tout=$_POST['Tout'];


        $conn = conexion("root", "");
        $stmt = $conn->prepare ("UPDATE InAndOut SET Tin = '$Tin', Tout = '$Tout' WHERE dia = '$Day' AND id = '$ID'");
        $stmt->execute();
if($stmt)
{
  if(isset($_POST['submit']))
  {
    echo "<script>window.close();</script>";
    //echo "<script>window.location.href ='admin/html/index.html';</script>";
    //echo "<script>window.location.reload();</script>";
  }
	//header("location: admin/html/index.html");
    //ob_end_flush();
    //die();
}
}
$conn = conexion("root", "");
$stmt1=$conn->prepare("SELECT Fname, Lname, Tin, Tout from InAndOut where ID='$ID' AND dia = '$Day'");
$stmt1->bindParam(':Fname', $Fname);
$stmt1->bindParam(':Lname', $Lname);
$stmt1->bindParam(':Tin', $Tin);
$stmt1->bindParam(':Tout', $Tout);
$stmt1->execute();

$row=$stmt1->fetch();


?>
<div class="uk-child-width-1-3@m uk-grid-small uk-grid-match" uk-grid>
    <div>
        
    </div>
    <div>
 <form method="POST" action="" enctype="multipart/form-data">
        
         <div class="uk-margin">


          <p  style="font-size: 20px;">You are about to change "<?php echo $row['Fname']. " " . $row['Lname']; ?>" time in/out information.</p>
             
            <input style="font-size: 30px;" class="input-control" type="text" placeholder="Time in" name="Tin" value="<?php echo $row['Tin']; ?>">
        </div>
        
         <div class="uk-margin">
            <input style="font-size: 30px;" class="input-control" type="text" placeholder="Time out" name="Tout" value="<?php echo $row['Tout']; ?>">
        </div>

         <button onclick="return confirm('Are the times you entered correct?')" style="font-size: 20px;" class="log-btn" type="submit" name="submit">Submit</button>
</form>
</div>

<!-- <div></div> -->
</div>
<?php
}
?>

</body>
</html>